import MyNavbar from "../../component/navbar/MyNavbar";

function About(){
    return(
        <>
         <MyNavbar/>
         <h1>about</h1>
        </>
    )
}

export default About;